import common.Command;
import models.CommandType;
import common.Response;
import managers.CollectionManager;
import managers.CommandManager;
import managers.FileManager;
import managers.JsonManager;

import java.util.Scanner;

public class ServerMain {

    public static void main(String[] args) {

        FileManager fileManager = new FileManager("data.json");
        CollectionManager collectionManager = new CollectionManager(fileManager.load());
        CommandManager commandManager = new CommandManager(collectionManager, fileManager);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine();

            Command command;

            try {
                command = JsonManager.parseCommand(input);
            } catch (Exception e) {
                System.out.println("Invalid command format");
                continue;
            }

            if (command == null) continue;

            if (command.getType() == CommandType.EXIT) {
                System.out.println("Exiting...");
                break;
            }

            Response response = commandManager.execute(command);
            System.out.println(response.getMessage());
        }
    }
}