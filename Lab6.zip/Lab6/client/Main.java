import builders.InteractiveHumanBeingBuilder;

import java.util.Scanner;
import models.CommandType;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        InteractiveHumanBeingBuilder builder = new InteractiveHumanBeingBuilder(scanner);

        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine();

            Command command = parse(input, builder);

            if (command == null) {
                System.out.println("Unknown command");
                continue;
            }

            if (command.getType() == CommandType.EXIT) {
                System.out.println("Bye!");
                break;
            }

            // пока без сети
            System.out.println("Command prepared: " + command.getType());
        }
    }

    private static Command parse(String input, InteractiveHumanBeingBuilder builder) {

        String[] parts = input.split(" ", 2);

        switch (parts[0]) {

            case "add":
                return new Command(CommandType.ADD, builder.build());

            case "clear":
                return new Command(CommandType.CLEAR, null);

            case "count_by_soundtrack_name":
                return new Command(CommandType.COUNT_BY_SOUNDTRACK_NAME,
                        parts.length > 1 ? parts[1] : null);

            case "exit":
                return new Command(CommandType.EXIT, null);

            case "filter_contains_name":
                return new Command(CommandType.FILTER_CONTAINS_NAME,
                        parts.length > 1 ? parts[1] : null);

            case "help":
                return new Command(CommandType.HELP, null);

            case "info":
                return new Command(CommandType.INFO, null);

            case "print_field_descending_impact_speed":
                return new Command(CommandType.PRINT_FIELD_DESCENDING_IMPACT_SPEED, null);

            case "remove_by_id":
                return new Command(CommandType.REMOVE_BY_ID,
                        Long.parseLong(parts[1]));

            case "remove_greater":
                return new Command(CommandType.REMOVE_GREATER,
                        builder.build());

            case "reorder":
                return new Command(CommandType.REORDER, null);

            case "show":
                return new Command(CommandType.SHOW, null);

            case "sort":
                return new Command(CommandType.SORT, null);

            case "update":
                return new Command(CommandType.UPDATE,
                        builder.build());

            default:
                return null;
        }
    }
}