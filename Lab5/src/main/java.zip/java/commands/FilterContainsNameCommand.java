package commands;

import managers.CollectionManager;

public class FilterContainsNameCommand implements Command{

    private CollectionManager manager;

    public FilterContainsNameCommand(CollectionManager m){
        manager=m;
    }

    public String getName(){return "filter_contains_name";}

    public void execute(String arg){

        manager.getCollection()
                .stream()
                .filter(h->h.getName().contains(arg))
                .forEach(System.out::println);

        System.out.println("Collection is filtered by name " + arg);
    }

    @Override
    public String getDescription() {
        return "filter_contains_name name : output the elements whose name field value contains the specified substring";
    }
}